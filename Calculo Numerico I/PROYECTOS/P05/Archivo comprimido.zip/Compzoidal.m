function I = Compzoidal(Fun, a, b, Er)

    % Calcula la integral de la función desde a hasta b con una precisión Er
    % utilizando el método del trapecio compuesto.

    % Entradas:
    %   Fun - función a integrar.
    %   a - límite inferior de integración.
    %   b - límite superior de integración.
    %   Er - tolerancia de error deseada.
 
    % Salida:
    %   I - integral aproximada de la función.

    % Inicializamos las variables.
    n = 1; % Número inicial de subintervalos.
    I_old = 0; % Valor inicial de la integral.
    I_new = (b - a) * (Fun(a) + Fun(b)) / 2;

    % Iteramos hasta que la diferencia sea menor que el error deseado.
    while abs(I_new - I_old) > Er
        I_old = I_new;
        n = 2 * n; % Nuevo número de subintervalos.
        h = (b - a) / n; % Tamaño de cada subintervalo.
        x = a + h:h:b - h; % Puntos intermedios.
        I_new = (Fun(a) + 2 * sum(Fun(x)) + Fun(b)) * h / 2; % Calculamos la integral con n subintervalos.
    end

    % Asignamos el resultado final a I.
    I = I_new;
end