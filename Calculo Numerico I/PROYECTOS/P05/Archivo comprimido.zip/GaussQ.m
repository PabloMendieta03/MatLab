function I = GaussQ(fun, a, b, n)
    % GaussQ calcula la integral de una función dada usando la cuadratura de Gauss.
    %
    % Entradas:
    %   y - función anónima que representa la función a integrar.
    %   a - límite inferior del intervalo de integración.
    %   b - límite superior del intervalo de integración.
    %   n - número de puntos/pesos a emplear en el cálculo.
    %
    % Salida:
    %   I - valor aproximado de la integral calculada.
    
    syms x;
    
    % Obtenemos el polinomio de Legendre de grado n y convertimos a
    % coeficientes polinomiales.
    P = legendreP(n, x);
    P = sym2poly(P);
    
    % Encontramos las raíces del polinomio de Legendre (nodos).
    xn = roots(P);
    
    % Inicializamos el vector de pesos.
    w = zeros(n, 1);
    
    % Calculamos los pesos para cada nodo usando los polinomios de Lagrange.
    for i = 1:n
        % Polinomio de Lagrange para el i-ésimo nodo.
        L = 1;
        for j = 1:n
            if i ~= j
                L = L * (x - xn(j)) / (xn(i) - xn(j));
            end
        end
        % Integramos el polinomio de Lagrange sobre el intervalo estándar.
        w(i) = int(L, x, -1, 1);
    end
    
    % Calculamosla integral aproximada utilizando los nodos y pesos calculados y 
    % transformando los nodos al intervalo [a, b]
    transformed_nodes = (b - a) / 2 * xn + (a + b) / 2;
    I = (b - a) / 2 * sum(w .* fun(transformed_nodes));
end
