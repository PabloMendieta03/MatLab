function I = PuntosSimpson(x, y)

    % PuntosSimpson realiza la integración numérica usando una combinación
    % de los métodos compuestos de Simpson de 1/3, 3/8 y el trapecio,
    % dependiendo del número de intervalos entre los puntos x.

    % Entradas:
    %   x - vector correspondiente a los valores de x.
    %   y - vector correspondiente a los valores de y.
 
    % Salida:
    %   I - integral aproximada de la función.

    n = length(x) - 1; % Número de intervalos.
    h = (x(end) - x(1)) / n; % Calculamos h.

    if mod(n, 3) == 0
        % Uso del método de Simpson 3/8 compuesto si n es divisible por 3.

        I = 0;

        for i=1:3:n-2
            I = I + (3*h/8) * (y(i) + 3*y(i+1) + 3*y(i+2) + y(i+3));
        end

        disp('Se ha empleado Simpson 3/8.');

    elseif mod(n, 3) == 1
        % Uso del método trapezoidal en el primer intervalo y Simpson 3/8
        % en el resto si al dividir n entre 3 hay resto 1.

        I = (h/2) * (y(1) + y(2));

        for i=2:3:n-2
            I = I + (3*h/8) * (y(i) + 3*y(i+1) + 3*y(i+2) + y(i+3));
        end

        disp('Se ha empleado Trapezoidal y Simpson 3/8.');

    else
        % Uso del método de Simpson 1/3 en los dos primeros intervalos y
        % Simpson 3/8 en el resto si al dividir n entre 3 hay resto 2.

        I = (h/3) * (y(1) + 4*y(2) + y(3));

        for i=3:3:n-2
            I = I + (3*h/8) * (y(i) + 3*y(i+1) + 3*y(i+2) + y(i+3));
        end

        disp('Se ha empleado Simpson 1/3 y Simpson 3/8.');

    end
end
