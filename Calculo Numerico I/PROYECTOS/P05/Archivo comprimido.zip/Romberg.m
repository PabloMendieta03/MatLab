function IR = Romberg(f, a, b, Ni, Niveles)

    % Romberg realiza la integración numérica usando el método de Romberg.

    % Entradas:
    %   f - función a integrar.
    %   a - límite inferior de integración.
    %   b - límite superior de integración.
    %   Ni - número inicial de subintervalos.
    %   Niveles - número de niveles de integración.

    % Salidas:
    %   IR - matriz con los distintos valores estimados de la integral.

    % Inicializamos la matriz IR.
    IR = zeros(Niveles, Niveles);
    
    % Calculamos las aproximaciones iniciales usando el método de los
    % trapecios.
    for k = 1:Niveles
        n = Ni * 2^(k-1);  % Número de subintervalos aumenta como 2^(k-1).
        IR(k, 1) = TrapeziosR(f, a, b, n);
    end
    
    % Aplicamos la extrapolación de Romberg.
    for j = 2:Niveles
        for i = j:Niveles
            IR(i, j) = IR(i, j-1) + (IR(i, j-1) - IR(i-1, j-1)) / (4^(j-1) - 1);
        end
    end
end