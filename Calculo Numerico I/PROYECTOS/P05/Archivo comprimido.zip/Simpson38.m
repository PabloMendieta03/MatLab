function I = Simpson38(y, a, b, Er)

    % Simpson38 realiza la integración numérica utilizando el método compuesto de Simpson 3/8.
    
    % Entradas:
    %   y  - función anónima que representa la función a integrar.
    %   a  - límite inferior del intervalo de integración.
    %   b  - límite superior del intervalo de integración.
    %   Er - error relativo máximo permitido para la convergencia.
    
    % Salida:
    %   I - aproximación de la integral.

    % Inicializamos las variables.
    n = 3;  % Mínimos subintervalos para Simpson 3/8.
    h = (b - a) / n;
    I_prev = 0;  % Almacenamos la integral de la iteración anterior.

    % Bucle hasta que el error relativo sea menor que Er.
    while true

        x = linspace(a, b, n+1);  % Puntos equidistantes incluyendo los extremos.
        f_values = y(x);  % Evaluamos la función en cada punto x.
        I = (3*h/8) * (f_values(1) + 3*sum(f_values(2:3:end-2)) + 3*sum(f_values(3:3:end-1)) + 2*sum(f_values(4:3:end-3)) + f_values(end));

        % Comprobamos si el error relativo es menor que Er.
        if abs(I - I_prev) / I < Er
            break;
        end

        I_prev = I;  % Actualizamos el valor de la integral anterior.
        n = n * 2;  % Doblamos el número de subintervalos.
        h = (b - a) / n;  % Recalculamos h.

    end
end
