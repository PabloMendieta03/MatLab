function I = TrapeziosR(fun, a, b, n)

    % TrapeziosR calcula la integral de una función usando el método de los trapecios compuestos.
    % Es una modificación de la función ya progamada anteriormente 'Compzoidal.m'.

    % Entradas:
    %   fun - función a integrar.
    %   a - límite inferior de integración.
    %   b - límite superior de integración.
    %   n - número de subintervalos.

    % Salidas:
    %   I - valor aproximado de la integral.

    % Tamaño de cada subintervalo.
    h = (b - a) / n;
    
    % Puntos intermedios.
    x = linspace(a, b, n+1);
    
    % Evaluamos la función en los puntos x.
    fx = fun(x);
    
    % Aplicamos la fórmula de los trapecios compuestos.
    I = (h/2) * (fx(1) + 2 * sum(fx(2:end-1)) + fx(end));
end